-- MySQL dump 10.13  Distrib 5.6.29-76.2, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: secretsanta
-- ------------------------------------------------------
-- Server version	5.6.29-76.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Entry`
--

DROP TABLE IF EXISTS `Entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `wishlist` longtext COLLATE utf8_unicode_ci,
  `viewdate` datetime DEFAULT NULL,
  `viewreminder_sent` datetime DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `wishlist_updated` tinyint(1) DEFAULT NULL,
  `updatewishlistreminder_sent` datetime DEFAULT NULL,
  `poolAdmin` tinyint(1) NOT NULL DEFAULT '0',
  `ipv4` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipv6` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `poolId` int(11) DEFAULT NULL,
  `entryId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EAE0B2748B3CFEDC` (`entryId`),
  KEY `IDX_EAE0B274E86EC8E2` (`poolId`),
  CONSTRAINT `FK_EAE0B2748B3CFEDC` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`) ON DELETE SET NULL,
  CONSTRAINT `FK_EAE0B274E86EC8E2` FOREIGN KEY (`poolId`) REFERENCES `Pool` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Entry`
--

LOCK TABLES `Entry` WRITE;
/*!40000 ALTER TABLE `Entry` DISABLE KEYS */;
/*!40000 ALTER TABLE `Entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Pool`
--

DROP TABLE IF EXISTS `Pool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Pool` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listurl` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8_unicode_ci NOT NULL,
  `creationdate` datetime NOT NULL,
  `sentdate` datetime DEFAULT NULL,
  `eventdate` datetime DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` tinyint(1) NOT NULL,
  `locale` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `exposed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Pool`
--

LOCK TABLES `Pool` WRITE;
/*!40000 ALTER TABLE `Pool` DISABLE KEYS */;
/*!40000 ALTER TABLE `Pool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `WishlistItem`
--

DROP TABLE IF EXISTS `WishlistItem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `WishlistItem` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_id` int(11) DEFAULT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_648910E8BA364942` (`entry_id`),
  CONSTRAINT `FK_648910E8BA364942` FOREIGN KEY (`entry_id`) REFERENCES `Entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `WishlistItem`
--

LOCK TABLES `WishlistItem` WRITE;
/*!40000 ALTER TABLE `WishlistItem` DISABLE KEYS */;
/*!40000 ALTER TABLE `WishlistItem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exclude`
--

DROP TABLE IF EXISTS `exclude`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exclude` (
  `entryId` int(11) NOT NULL,
  `excludedEntryId` int(11) NOT NULL,
  PRIMARY KEY (`entryId`,`excludedEntryId`),
  KEY `IDX_6282E7798B3CFEDC` (`entryId`),
  KEY `IDX_6282E7792DFCEACA` (`excludedEntryId`),
  CONSTRAINT `FK_6282E7792DFCEACA` FOREIGN KEY (`excludedEntryId`) REFERENCES `Entry` (`id`),
  CONSTRAINT `FK_6282E7798B3CFEDC` FOREIGN KEY (`entryId`) REFERENCES `Entry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exclude`
--

LOCK TABLES `exclude` WRITE;
/*!40000 ALTER TABLE `exclude` DISABLE KEYS */;
/*!40000 ALTER TABLE `exclude` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-15 15:01:08
